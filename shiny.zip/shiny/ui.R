################# CSDA1040 - PROJECT 2 - TEXT MINING USING TWITTER DATA ##############
################# APP INTERFACE BUILT BY STAN TAOV  ##################################


library(shiny)

ui <- fluidPage(
  
  # App title ----
  titlePanel("Twitter Analytical Dashboard for Airlines"),
  
  sidebarLayout(
    # Sidebar with a slider and selection inputs
    sidebarPanel(
      selectInput("selection", "Choose an Airline:",
                  choices = airlines),
      sliderInput("freq",
                  "Minimum Frequency:",
                  min = 1,  max = 50, value = 5),
      sliderInput("max",
                  "Maximum Number of Words:",
                  min = 1,  max = 300,  value = 50),
      sliderInput("clusters",
                  "Number of Clusters:",
                  min = 1,  max = 12,  value = 9),
      actionButton("update", "Go"),
      hr()
    ),
    
    # Show Plots
    mainPanel(
      plotOutput("plot"),
      plotOutput("freqPlot"),
      plotOutput(outputId = 'plot2'),
      plotOutput(outputId = 'plot3')
      
    )
  )
)


