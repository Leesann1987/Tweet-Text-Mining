################# CSDA1040 - PROJECT 2 - TEXT MINING USING TWITTER DATA ##############
################# APP INTERFACE BUILT BY STAN TAOV  ##################################


server <- function(input, output, session) {
  # Define a reactive expression for the document term matrix
  terms <- reactive({
    # Change when the "update" button is pressed...
    input$update
    isolate({
      withProgress({
        setProgress(message = "Processing corpus...")
        getTermMatrix(input$selection)
      })
    })
  })
  
  
  terms_2 <- reactive({
    input$update
    isolate({
      getConditionedDataFrame(terms())
    })
  })
  
  terms_3 <- reactive({
    input$update
    isolate({
      withProgress({
        setProgress(message = "Processing corpus...")
        model(input$selection)
      })
    })
  })
  
  terms_4 <- reactive({
    input$update
    isolate({
      withProgress({
        setProgress(message = "Processing corpus...")
        hierarchical(input$selection)
      })
    })
  })
  
  
  
  
  
  #word cloud plot
  wordcloud_rep <- repeatable(wordcloud)
  
  output$plot <- renderPlot({
    v <- terms()
    wordcloud_rep(names(v), v, scale=c(3.5,0.25),
                  min.freq = input$freq, max.words=input$max,
                  colors=brewer.pal(8, "Dark2"))
  })
  
  #word frequency barplot
  hues <- c(60:330)
  output$freqPlot <- renderPlot({
    v <- terms_2()
    ggplot(v, aes(x=reorder(term, freq), y=freq, fill = as.factor(term))) +
      geom_bar(stat = "identity", position = "dodge", col= "black") + xlab("Terms") + ylab("Count") + 
      scale_fill_hue(c = sample(hues, 1)) + 
      ggtitle("Word Frequency") + 
      theme(axis.text.x = element_text(angle = 90)) +
      guides(fill=FALSE)
  })
  
  #model plot
  output$plot2 <- renderPlot({
    v <- terms_3()
    v %>%
      mutate(term = reorder_within(term, beta, topic)) %>%
      ggplot(aes(term, beta, fill = factor(topic))) +
      geom_col(show.legend = FALSE) +
      facet_wrap(~ topic, scales = "free") +
      coord_flip() +
      scale_x_reordered() +
      ggtitle("Topic Model") + 
      theme(plot.title = element_text(lineheight=.8, face="bold"))
    
  })
  
  #hierarchical plot
  
  output$plot3 <- renderPlot({
    v <- terms_4()
    plot(v)
    rect.hclust(v, k = input$clusters) # cut tree into 9 clusters
    
  })
  
  
  
  
}

#shinyApp(ui, server)
