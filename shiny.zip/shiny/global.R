################# CSDA1040 - PROJECT 2 - TEXT MINING USING TWITTER DATA ##############
################# APP INTERFACE BUILT BY STAN TAOV  ##################################

library(tidyr)
library(dplyr)
library(tidytext)
library(textdata)
library(broom)
library(ggplot2)
library(reshape2)
library(wordcloud)
library(tm)
library(ggthemes)
library(textclean)
library(stringr)
library(twitteR)
library(topicmodels)
library(gsubfn)
library(htmlTable)
library(proto)
library(shiny)
library(memoise)
library(textmineR)
library(stopwords)

## Loading data

#data_shiny <- load("data_shiny.RData")
#data <- load("data.RData")

#saveRDS(data_shiny, file = "data_shiny.rds")
#saveRDS(data, file = "data.rds")

data_shiny <- readRDS("data_shiny.rds")
data <- readRDS("data.rds")


airlines <- c("Southwest",
              "United",
              "Delta",
              "US Airways",
              "American",
              "Virgin America")

va <- data %>%
  filter(airline == "Virgin America")

un <- data %>%
  filter(airline == "United")

sw <- data %>%
  filter(airline == "Southwest")

dl <- data %>%
  filter(airline == "Delta")

us <- data %>%
  filter(airline == "US Airways")

am <- data %>%
  filter(airline == "American")

############### Word Cloud Function ############### 

getTermMatrix <- memoise(function(airline) {
  
  if (!(airline %in% airlines))
    stop("Unknown airline")
  
  if (airline  == "Virgin America") {
    text <- va$text
  }
  
  if (airline  == "United") {
    text <- un$text
  }
  
  if (airline  == "Southwest") {
    text <- sw$text
  }
  
  if (airline  == "Delta") {
    text <- dl$text
  }
  
  if (airline  == "US Airways") {
    text <- us$text
  }
  
  if (airline  == "American") {
    text <- am$text
  }
  
  
  myCorpus = Corpus(VectorSource(text))
  myCorpus = tm_map(myCorpus, content_transformer(tolower))
  myCorpus = tm_map(myCorpus, removePunctuation)
  myCorpus = tm_map(myCorpus, removeNumbers)
  myCorpus = tm_map(myCorpus, removeWords,
                    c(stopwords("SMART"), "thy", "thou", "thee", "the", "and", "but", "united", "flight", 
                      "virginamerica", "southwestair", "american", "jetblue", "usairways", "americanair"))
  
  
  myDTM = TermDocumentMatrix(myCorpus,
                             control = list(minWordLength = 1))
  
  m = as.matrix(myDTM)
  
  sort(rowSums(m), decreasing = TRUE)
})

############### Word Frequency Function ############### 

getConditionedDataFrame <- function(terms) {
  #create the term matrix
  # calculate the frequency of words and sort it by frequency
  word.freq <- subset(terms, terms >= 25)
  df <- data.frame(term = names(word.freq), freq = word.freq)
  return(df)
}

############### Topic Model Function ############### 

model <- memoise(function(airline) {
  
  if (airline  == "Virgin America") {
    text <- data_shiny %>%
      filter(airline == "Virgin America")
  }
  
  if (airline  == "United") {
    text <- data_shiny %>%
      filter(airline == "United")
  }
  
  if (airline  == "Southwest") {
    text <- data_shiny %>%
      filter(airline == "Southwest")
  }
  
  if (airline  == "Delta") {
    text <- data_shiny %>%
      filter(airline == "Delta")
  }
  
  if (airline  == "US Airways") {
    text <- data_shiny %>%
      filter(airline == "US Airways")
  }
  
  if (airline  == "American") {
    text <- data_shiny %>%
      filter(airline == "American")
  }
  
  
  data_model <- subset(text, select = c(tweet_id, word))
  
  clean_tokens <- data_model
  clean_tokens$word <- gsubfn('[[:digit:]]+', '', clean_tokens$word)
  clean_tokens$word <- gsubfn('[[:punct:]]+', '', clean_tokens$word)
  
  
  clean_tokens <- clean_tokens %>%
    filter(!(nchar(word) == 1))
  
  
  data_tokens <- clean_tokens %>%
    filter(!(word==""))
  
  data_tokens <- data_tokens %>%
    mutate(ind = row_number())
  
  data_tokens <- data_tokens %>%
    group_by(tweet_id) %>%
    mutate(ind = row_number()) %>%
    tidyr::spread(key = ind, value = word)
  
  data_tokens[is.na(data_tokens)] <- ""
  
  data_tokens <- tidyr::unite(data_tokens, word,-tweet_id,sep =" " )
  data_tokens$word <- trimws(data_tokens$word)
  
  #Create a DocumentTermMatrix
  
  
  dtm2 <- CreateDtm(data_tokens$word,
                    doc_names = data_tokens$tweet_id,
                    ngram_window = c(1, 2),
                    stopword_vec = c(stopwords::stopwords(language = "en",
                                                          source = "smart")))
  
  data_lda <- LDA(dtm2, k=6, control = list(seed = 1234))
  
  data_topics <- tidy(data_lda, matrix = 'beta')
  
  data_top_terms <- data_topics %>%
    group_by(topic) %>%
    top_n(10, beta) %>%
    ungroup() %>%
    arrange(topic, -beta)
  
})


############### Hierarchical Clustering Function ############### 

hierarchical <- memoise(function(airline) {
  
  if (!(airline %in% airlines))
    stop("Unknown airline")
  
  if (airline  == "Virgin America") {
    text <- va$text
  }
  
  if (airline  == "United") {
    text <- un$text
  }
  
  if (airline  == "Southwest") {
    text <- sw$text
  }
  
  if (airline  == "Delta") {
    text <- dl$text
  }
  
  if (airline  == "US Airways") {
    text <- us$text
  }
  
  if (airline  == "American") {
    text <- am$text
  }
  
  
  myCorpus = Corpus(VectorSource(text))
  myCorpus = tm_map(myCorpus, content_transformer(tolower))
  myCorpus = tm_map(myCorpus, removePunctuation)
  myCorpus = tm_map(myCorpus, removeNumbers)
  myCorpus = tm_map(myCorpus, removeWords,
                    c(stopwords("SMART"), "thy", "thou", "thee", "the", "and", "but", "united", "flight", 
                      "virginamerica", "southwestair", "american", "jetblue", "usairways", "americanair"))
  
  
  myDTM = TermDocumentMatrix(myCorpus,
                             control = list(minWordLength = 1))
  
  tdm <- removeSparseTerms(myDTM, sparse = 0.98)
  m <- as.matrix(tdm)
  # cluster terms
  distMatrix <- dist(scale(m))
  fit <- hclust(distMatrix, method = "ward.D2")
  
})



